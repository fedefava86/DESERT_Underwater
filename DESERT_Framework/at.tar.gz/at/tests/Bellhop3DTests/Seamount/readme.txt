
Where I left it:

There's an odd discontinuity in the field at a certain range.

There are several factors that make this case difficult:
1) frequency is 5 Hz
2) receiver is at 100 m (within a third of a wavelength of the surface)
3) the radius of curvature of the cone gets vanishingly small

It's hard to understand the cause of the discontinuity because it's hard to visualize the 3D field and understand which rays contribute where.
Have been looking at vertical and horizontal slices.
