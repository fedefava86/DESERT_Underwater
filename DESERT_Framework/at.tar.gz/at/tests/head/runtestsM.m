% Run test for head wave problem

sparcM head
fieldsco head.grn.mat
plotmovie head.shd.mat
