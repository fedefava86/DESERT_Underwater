
scooter MunkS

%%
stack

%%
plotts MunkS.rts.mat
axis( [ 6 13 0 5000 ] )

print -dsvg MunkTS