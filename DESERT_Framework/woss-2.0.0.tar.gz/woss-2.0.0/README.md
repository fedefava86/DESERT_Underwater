# World Ocean Simulation System - WOSS - 

Please refer to:
  - INSTALL.md for installation info
  - COPYRIGHY.md for copyright terms
  - LICENSE.md for license terms
  - ACKNOWLEDGEMENTS.md for acknowledgements info
  - CHANGELOG.md for changelog info

A detailed doxygen documentation is embedded in the source code.
If you need to read it in html format please install doxygen on 
your system, and launch the following:

`doxygen`

further info and documentation can be found at 
https://woss.dei.unipd.it
