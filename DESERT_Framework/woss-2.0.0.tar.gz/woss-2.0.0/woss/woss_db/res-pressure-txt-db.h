/* WOSS - World Ocean Simulation System -
 * 
 * Copyright (C) 2009 2025 Federico Guerra
 * and regents of the SIGNET lab, University of Padova
 *
 * Author: Federico Guerra - WOSS@guerra-tlc.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */ 


/**
 * @file   res-pressure-txt-db.h
 * @author Federico Guerra
 * 
 * \brief Provides the interface for woss::ResPressureTxtDb class
 *
 * Provides the interface for the woss::ResPressureTxtDb class
 */


#ifndef WOSS_RES_PRESSURE_TXT_DB_H
#define WOSS_RES_PRESSURE_TXT_DB_H


#include <map>
#include <complex>
#include <custom-precision-double.h>
#include "woss-db.h"


namespace woss {


  /**
  * \brief Textual WossDb for Pressure
  *
  * ResPressureTxtDb implements WossTextualDb and WossResPressDb for storing calculated Pressure into a text file
  *
  **/
  class ResPressureTxtDb : public WossTextualDb, public WossResPressDb {

    
    public:


    /**
    * ResPressureTxtDb constructor
    * @param name pathname of database
    **/
    ResPressureTxtDb( const std::string& name );

    virtual ~ResPressureTxtDb() override = default;


    /**
    * Closes the connection to the text file provided
    * @return <i>true</i> if method was successful, <i>false</i> otherwise
    **/
    virtual bool closeConnection() override;


    /**
    * Post openConnection() actions
    * @return <i>true</i> if method was successful, <i>false</i> otherwise
    **/
    virtual bool finalizeConnection() override;


    /**
    * Returns a pointer to a heap-created Pressure for given frequency, 
    * transmitter and receiver coordinates if present in the database.
    * <b>User is responsible of pointer's ownership</b>
    * @param coord_tx const reference to a valid CoordZ object
    * @param coord_rx const reference to a valid CoordZ object
    * @param frequency used frequency [hz]
    * @param time_value const reference to a valid Time object
    * @return <i>valid</i> std::unique_ptr with a valid Pressure if parameters are found, <i>not valid</i> otherwise
    **/  
    virtual std::unique_ptr<Pressure> getValue( const CoordZ& coord_tx, const CoordZ& coord_rx, const double frequency, const Time& time_value ) const override;


    /**
    * Inserts the given Pressure value in the pressure_map at given frequency, transmitter and receiver coordinates
    * @param coord_tx const reference to a valid CoordZ object
    * @param coord_rx const reference to a valid CoordZ object
    * @param frequency used frequency [hz]
    * @param time_value const reference to a valid Time object
    * @param pressure computed Pressure
    **/
    virtual bool insertValue( const CoordZ& coord_tx, const CoordZ& coord_rx, const double frequency, const Time& time_value, const Pressure& pressure ) override;


    static void setSpaceSampling( double value ) { space_sampling = value; }
    
    static double getSpaceSampling() { return space_sampling; }
    
    
    protected:


    using TimeMap = std::map< time_t, std::complex< double > >;
    using TMIter = TimeMap::iterator;
    using TMCIter = TimeMap::const_iterator;
    using TMRIter = TimeMap::reverse_iterator;
    
    using FreqMap = std::map< PDouble, TimeMap >;
    using FMIter = FreqMap::iterator;
    using FMCIter = FreqMap::const_iterator;
    using FMRIter = FreqMap::reverse_iterator;
    
    using RxMap = std::map< CoordZ, FreqMap, CoordComparator< ResPressureTxtDb, CoordZ > >;
    using RxMIter = RxMap::iterator;
    using RxCIter = RxMap::const_iterator;
    using RxMRIter = RxMap::reverse_iterator;
       
    /**
    * Multidimensional map that links a transmitter CoordZ to a receiver CoordZ to a frequency PDouble value 
    * and finally to a Pressure value
    **/
    using PressureMatrix = std::map< CoordZ, RxMap, CoordComparator< ResPressureTxtDb, CoordZ > >;
    using PMIter = PressureMatrix::iterator;
    using PMCIter = PressureMatrix::const_iterator;
    using PMRIter = PressureMatrix::reverse_iterator;
    using PMCRIter = PressureMatrix::const_reverse_iterator;
  
  
    static double space_sampling;

    /**
    * PressureMatrix map for storing imported and user inserted Pressure values
    **/
    PressureMatrix pressure_map;

    /**
    * pressure_map's initial size. If pressure_map's size is greater on closeConnection() the map will be written to disk
    **/
    int initial_pressmap_size;

    bool has_been_modified;
    
    
    /**
    * Prints pressure_map to screen. The columns format is the following: \n
    * <b> tx latitude, tx longitude, tx depth, rx latitude, rx longitude, rx depth, frequency, real pressure, imag pressure</b>
    * @returns <i>true</i> if operation succeeds, <i>false</i> otherwise
    **/  
    void printScreenMap();

    /**
    * Writes pressure_map to textual files. The columns format is the following: \n
    * <b> tx latitude, tx longitude, tx depth, rx latitude, rx longitude, rx depth, frequency, real pressure, imag pressure</b>
    * @returns <i>true</i> if operation succeeds, <i>false</i> otherwise
    **/  
    virtual bool writeMap();

    /**
    * Imports the formatted textual files into pressure_map. The column format is the following: \n
    * <b> tx latitude, tx longitude, tx depth, rx latitude, rx longitude, rx depth, frequency, real pressure, imag pressure</b>
    * @returns <i>true</i> if operation succeeds, <i>false</i> otherwise
    **/  
    virtual bool importMap();

    
    /**
    * Reads given values from pressure_map
    * @param tx valid transmitter coordinates
    * @param rx valid receiver coordinates
    * @param frequency frequency [hz]
    * @param time_value const reference to a valid time_value
    * @return valid Pressure if parameters are found, not valid otherwise
    **/
    std::complex<double> readMap( const CoordZ& tx, const CoordZ& rx, const double frequency, const Time& time_value ) const;

    
  };


}
#endif /* WOSS_RES_PRESSURE_TXT_DB_H */ 


 
