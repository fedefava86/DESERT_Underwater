# Acknowledgements

WOSS 1.x has been developed by Federico Guerra 
and SIGNET lab, University of Padova, 
in collaboration with the NATO Centre for Maritime 
Research and Experimentation (http://www.cmre.nato.int 
; E-mail: pao@cmre.nato.int), 
whose support is gratefully acknowledged.

The development of:
* the option to simulate the time evolution of environmental parameters
* the option to model surface waves using realistic wave spectra 

has been supported in part by the European Commission under the 7th Framework Programme, CLAM project (Grant Agreement no. 258359).

The development of the command line script test has been developed under the "NATO OTAN SPS G5884" project.
